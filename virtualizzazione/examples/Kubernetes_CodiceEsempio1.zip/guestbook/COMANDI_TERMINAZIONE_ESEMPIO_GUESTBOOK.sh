#  cd /cygdrive/c/DIDATTICA/SystemsIntegration_AmministrazioneDiSistemi/DISPENSE/MINIKUBE
#  cd ./examples-master/guestbook

function VISUALIZZA_COMANDO_ED_ESEGUI {
	echo $@
	$@
}

VISUALIZZA_COMANDO_ED_ESEGUI kubectl delete deployment -l app=redis
VISUALIZZA_COMANDO_ED_ESEGUI kubectl delete service -l app=redis
VISUALIZZA_COMANDO_ED_ESEGUI kubectl delete deployment -l app=guestbook
VISUALIZZA_COMANDO_ED_ESEGUI kubectl delete service -l app=guestbook
VISUALIZZA_COMANDO_ED_ESEGUI kubectl get services
VISUALIZZA_COMANDO_ED_ESEGUI kubectl delete service ClusterIP
VISUALIZZA_COMANDO_ED_ESEGUI kubectl delete service -l ClusterIP
VISUALIZZA_COMANDO_ED_ESEGUI kubectl get services
VISUALIZZA_COMANDO_ED_ESEGUI kubectl delete service kubernetes
VISUALIZZA_COMANDO_ED_ESEGUI kubectl get services

#   minikube stop

