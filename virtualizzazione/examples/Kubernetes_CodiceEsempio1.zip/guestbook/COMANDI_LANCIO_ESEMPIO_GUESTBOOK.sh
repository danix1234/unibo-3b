#  cd /cygdrive/c/DIDATTICA/SystemsIntegration_AmministrazioneDiSistemi/DISPENSE/MINIKUBE
#  minikube start
#  cd ./examples-master/guestbook

function VISUALIZZA_COMANDO_ED_ESEGUI {
	echo $@
	$@
}

VISUALIZZA_COMANDO_ED_ESEGUI kubectl apply -f redis-master-deployment.yaml
sleep 1
VISUALIZZA_COMANDO_ED_ESEGUI kubectl get pods
VISUALIZZA_COMANDO_ED_ESEGUI kubectl logs -f redis-master-596696dd4-m78q8
VISUALIZZA_COMANDO_ED_ESEGUI kubectl apply -f redis-master-service.yaml
sleep 1
VISUALIZZA_COMANDO_ED_ESEGUI kubectl get service
VISUALIZZA_COMANDO_ED_ESEGUI kubectl apply -f redis-slave-deployment.yaml
sleep 1
VISUALIZZA_COMANDO_ED_ESEGUI kubectl get pods
VISUALIZZA_COMANDO_ED_ESEGUI kubectl apply -f redis-slave-service.yaml
sleep 1
VISUALIZZA_COMANDO_ED_ESEGUI kubectl get service
VISUALIZZA_COMANDO_ED_ESEGUI kubectl get pods
VISUALIZZA_COMANDO_ED_ESEGUI kubectl apply -f frontend-deployment.yaml
sleep 1
VISUALIZZA_COMANDO_ED_ESEGUI kubectl get pods -l app=guestbook -l tier=frontend
VISUALIZZA_COMANDO_ED_ESEGUI kubectl apply -f frontend-service.yaml
sleep 1
VISUALIZZA_COMANDO_ED_ESEGUI kubectl get services
VISUALIZZA_COMANDO_ED_ESEGUI minikube service frontend --url
VISUALIZZA_COMANDO_ED_ESEGUI kubectl get service frontend
  
#  curl http://192.168.99.100:32468
#  ping 192.168.99.100
