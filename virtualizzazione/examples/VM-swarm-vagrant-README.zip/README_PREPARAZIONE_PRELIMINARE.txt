Generate self signed certificate
da mettere nel nodo manager.
Il nodo manager funge anche da nodo che contiene il registry

Per prima cosa, nella macchina fisica in cui creo le VM,
devo eseguire questo comando, che crea i certificati
self-signed e li mette nei due files registry.key e registry.crt

Il nome host manager deve avere lo stesso indirizzo IP
INTERNO del nodo manager e deve essere inserito nel file
/etc/hosts 

Il comando da lanciare e' il seguente:

$ openssl req -newkey rsa:4096 -nodes -sha256 \
  -keyout registry.key -x509 -days 3650 \
  -out registry.crt

E questo e' l'output che si ottiene.
Le risposte sono quelle visualizzate.
L'unica importante e' la domanda  "Common Name"
a cui si risponde manager



Generating a RSA private key
.....................................++++
..................................................................................................................................................................................................................................................................................++++
writing new private key to 'registry.key'
-----
You are about to be asked to enter information that will be incorporated
into your certificate request.
What you are about to enter is what is called a Distinguished Name or a DN.
There are quite a few fields but you can leave some blank
For some fields there will be a default value,
If you enter '.', the field will be left blank.
-----
Country Name (2 letter code) [XX]:it
State or Province Name (full name) []:italy
Locality Name (eg, city) [Default City]:cesena
Organization Name (eg, company) [Default Company Ltd]:unibo
Organizational Unit Name (eg, section) []:
Common Name (eg, your name or your server's hostname) []:manager
Email Address []:


