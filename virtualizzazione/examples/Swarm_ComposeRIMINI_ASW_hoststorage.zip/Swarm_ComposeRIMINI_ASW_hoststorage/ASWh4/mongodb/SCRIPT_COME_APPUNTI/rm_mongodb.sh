
docker rm mongodb

