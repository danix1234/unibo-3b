
docker rmi mymongo

