
docker stop mongodb

